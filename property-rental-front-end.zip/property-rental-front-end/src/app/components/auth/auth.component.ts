import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="auth-container">
      <form (ngSubmit)="onSubmit()">
        <h2>{{ isLogin ? 'Login' : 'Register' }}</h2>
        
        <div class="form-group" *ngIf="!isLogin">
          <label>Name</label>
          <input type="text" [(ngModel)]="name" name="name" required>
        </div>

        <div class="form-group">
          <label>Email</label>
          <input type="email" [(ngModel)]="email" name="email" required pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$">
          <div *ngIf="email && !email.match('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')" class="error-message">
            Please enter a valid email address.
          </div>
        </div>

        <div class="form-group">
          <label>Password</label>
          <input type="password" [(ngModel)]="password" name="password" required>
        </div>

        <div class="form-group" *ngIf="!isLogin">
          <label>Phone</label>
          <input type="text" [(ngModel)]="phone" name="phone" pattern="^[0-9]{10}$">
          <div *ngIf="phone && !phone.match('^[0-9]{10}$')" class="error-message">
            Please enter a valid 10-digit phone number.
          </div>
        </div>

        <div class="form-group" *ngIf="!isLogin">
          <label>Role</label>
          <select [(ngModel)]="role" name="role" required>
            <option value="landlord">Landlord</option>
            <option value="tenant">Tenant</option>
          </select>
        </div>

        <div class="form-group" *ngIf="!isLogin">
          <label>Profile Picture URL</label>
          <input type="text" [(ngModel)]="profilePicture" name="profilePicture">
        </div>

        <button type="submit" class="btn-primary">{{ isLogin ? 'Login' : 'Register' }}</button>
        
        <p class="toggle-mode">
          {{ isLogin ? 'Need an account?' : 'Already have an account?' }}
          <a href="#" (click)="toggleMode($event)">
            {{ isLogin ? 'Register' : 'Login' }}
          </a>
        </p>
      </form>
    </div>
  `,
  styles: [`
    body {
      background-color: #f0f4f8;
      font-family: Arial, sans-serif;
    }

    .auth-container {
      max-width: 400px;
      margin: 2rem auto;
      padding: 2rem;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      background-color: #ffffff;
    }

    .auth-container h2 {
      text-align: center;
      margin-bottom: 1.5rem;
      color: #333;
    }

    .form-group {
      margin-bottom: 1rem;
    }

    .form-group label {
      display: block;
      margin-bottom: 0.5rem;
      color: #555;
    }

    .form-group input,
    .form-group select {
      width: 100%;
      padding: 0.5rem;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    .form-group input:focus,
    .form-group select:focus {
      border-color: #007bff;
      outline: none;
    }

    .btn-primary {
      width: 100%;
      padding: 0.75rem;
      background-color: #007bff;
      border: none;
      border-radius: 4px;
      color: #fff;
      font-size: 1rem;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .btn-primary:hover {
      background-color: #0056b3;
    }

    .toggle-mode {
      text-align: center;
      margin-top: 1rem;
    }

    .toggle-mode a {
      color: #007bff;
      text-decoration: none;
      cursor: pointer;
    }

    .toggle-mode a:hover {
      text-decoration: underline;
    }

    .error-message {
      color: red;
      font-size: 0.875rem;
      margin-top: 0.25rem;
    }
  `]
})
export class AuthComponent {
  isLogin = true;
  email = '';
  password = '';
  name = '';
  phone = '';
  role = '';
  profilePicture = '';

  constructor(private authService: AuthService, private router: Router) {}

  onSubmit() {
    if (this.isLogin) {
      this.authService.login({ email: this.email, password: this.password })
        .subscribe({
          next: (response) => {
            localStorage.setItem('user', JSON.stringify(response?.user));
            this.router.navigate(['/home']);
          },
          error: (error) => {
            console.error('Login failed:', error);
            alert('Login failed: ' + (error.error?.message || 'Unknown error'));
          }
        });
    } else {
      this.authService.register({ 
        email: this.email, 
        password: this.password,
        name: this.name,
        phone: this.phone,
        role: this.role,
        profilePicture: this.profilePicture
      }).subscribe({
        next: (response) => {
          alert('Registration successful! Please log in.');
          this.toggleMode(new Event('click'));
        },
        error: (error) => {
          console.error('Registration failed:', error);
          alert('Registration failed: ' + (error.error?.message || 'Unknown error'));
        }
      });
    }
  }

  toggleMode(event: Event) {
    event.preventDefault();
    this.isLogin = !this.isLogin;
  }
}