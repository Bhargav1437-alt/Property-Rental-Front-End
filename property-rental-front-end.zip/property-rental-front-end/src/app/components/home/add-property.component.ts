import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { state } from '@angular/animations';

@Component({
  selector: 'app-add-property',
  standalone: true,
  template: `
    <div class="modal-overlay" (click)="onClose()">
      <div class="modal" (click)="$event.stopPropagation()">
        <button class="close-button" (click)="onClose()">X</button>
        <h2 class="modal-header">{{ propertyToEdit ? 'Edit Property' : searchProperty ? 'search Property' : 'Add Property' }}</h2>
        <form [formGroup]="propertyForm" (ngSubmit)="onSubmit()">
          <div class="form-grid">
            <div class="form-group">
              <label for="title">Title:</label>
              <input id="title" type="text" formControlName="title" required />
            </div>
            <div class="form-group" *ngIf="!searchProperty">
              <label for="rentPrice">Rent Price:</label>
              <input id="rentPrice" type="number" formControlName="rentPrice" required />
            </div>
            <div class="form-group" *ngIf="!searchProperty">
              <label for="address">Address:</label>
              <input id="address" type="text" formControlName="address" required />
            </div>

            <!-- Country Dropdown -->
            <div class="form-group">
              <label for="country">Country:</label>
              <select id="country" formControlName="country" (change)="onCountryChange($event)">
                <option *ngFor="let country of countries" [value]="country">{{ country }}</option>
              </select>
            </div>

            <!-- State Dropdown -->
            <div class="form-group">
              <label for="state">State:</label>
              <select id="state" formControlName="state" (change)="onStateChange($event)">
                <option *ngFor="let state of states" [value]="state">{{ state }}</option>
              </select>
            </div>

            <!-- City Dropdown -->
            <div class="form-group">
              <label for="city">City:</label>
              <select id="city" formControlName="city" (change)="onCityChange($event)">
                <option *ngFor="let city of cities" [value]="city">{{ city }}</option>
              </select>
            </div>

            <div class="form-group">
              <label for="bedrooms">Bedrooms:</label>
              <input id="bedrooms" type="number" formControlName="bedrooms" required />
            </div>
            <div class="form-group" *ngIf="!searchProperty">
              <label for="description">Description:</label>
              <textarea id="description" formControlName="description"></textarea>
            </div>
            <div class="form-group" *ngIf="searchProperty">
              <label for="minAmount">Minimum Amount:</label>
              <input id="minAmount" type="text" formControlName="minAmount" required />
            </div>
            <div class="form-group" *ngIf="searchProperty">
              <label for="maxAmount">Maximum Amount:</label>
              <input id="maxAmount" type="text" formControlName="maxAmount" required />
            </div>
            <div class="form-group">
              <label for="propertyType">Property Type:</label>
              <select id="propertyType" formControlName="propertyType" required>
                <option *ngFor="let type of propertyTypes" [value]="type">{{ type }}</option>
              </select>
            </div>
            <div class="form-group">
              <label for="status">Status:</label>
              <select id="status" formControlName="status" required>
                <option *ngFor="let status of statuses" [value]="status">{{ status }}</option>
              </select>
            </div>
            <div class="form-group">
              <label for="furnished">Furnished:</label>
              <select id="furnished" formControlName="furnished" required>
                <option *ngFor="let level of furnishedLevels" [value]="level">{{ level }}</option>
              </select>
            </div>
            <div class="form-group checkbox">
              <input type="checkbox" formControlName="parkingIncluded" id="parkingIncluded" />
              <label for="parkingIncluded">Parking Included</label>
            </div>
            <div class="form-group checkbox">
              <input type="checkbox" formControlName="petsAllowed" id="petsAllowed" />
              <label for="petsAllowed">Pets Allowed</label>
            </div>
          </div>
          <div class="button-group">
            <button type="submit" 
            [disabled]="searchProperty ? false : !isFormChanged()"
            >{{ propertyToEdit ? 'Edit Property' : searchProperty ? 'search Property' : 'Add Property' }}</button>
            <button type="button" (click)="onClose()">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [`
    /* Import Google Font */
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

    /* Modal Overlay */
    .modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      justify-content: center;
      align-items: center;
      transition: background-color 0.3s ease;
    }
    
    /* Modal */
    .modal {
      background-color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      max-width: 800px;
      width: 100%;
      position: relative;
      overflow-y: auto;
      height: 80%;
      transition: all 0.3s ease-in-out;
      font-family: 'Poppins', sans-serif;
    }

    /* Close Button */
    .close-button {
      position: absolute;
      top: 10px;
      right: 10px;
      background-color: transparent;
      border: none;
      cursor: pointer;
      font-size: 20px;
      color: #333;
      font-weight: bold;
      border-radius: 50%;
      transition: background-color 0.3s ease;
    }

    .close-button:hover {
      background-color: rgba(0, 0, 0, 0.1);
    }

    /* Modal Header */
    .modal-header {
      font-size: 2rem;
      font-weight: 600;
      color: #333;
      text-align: center;
      margin-bottom: 20px;
      font-family: 'Poppins', sans-serif;
      text-transform: uppercase;
      letter-spacing: 1px;
      border-bottom: 2px solid #f1f1f1;
      padding-bottom: 10px;
    }

    /* Form Grid */
    .form-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px;
      margin-bottom: 20px;
    }

    /* Form Group */
    .form-group {
      display: flex;
      flex-direction: column;
      margin-bottom: 15px;
    }

    label {
      font-size: 1.1rem;
      color: #555;
      margin-bottom: 5px;
      font-family: 'Poppins', sans-serif;
      font-weight: 500;
    }

    /* Input, Select, and Textarea */
    input, select, textarea {
      padding: 12px;
      font-size: 1rem;
      border: 2px solid #ccc;
      border-radius: 8px;
      transition: border 0.3s ease;
      font-family: 'Poppins', sans-serif;
    }

    input:focus, select:focus, textarea:focus {
      border-color: #007bff;
      outline: none;
    }

    textarea {
      resize: vertical;
      min-height: 100px;
    }

    /* Checkbox */
    .checkbox {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
    }

    .checkbox input {
      margin-right: 10px;
    }

    /* Button Group */
    .button-group {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
    }

    button {
      padding: 12px 25px;
      font-size: 1.1rem;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    button[type="submit"] {
      background-color: #4CAF50;
    }

    button[type="submit"]:disabled {
      background-color: #b5e1a6;
      cursor: not-allowed;
    }

    button[type="submit"]:hover {
      background-color: #45a049;
    }

    button[type="button"] {
      background-color: #f44336;
    }

    button[type="button"]:hover {
      background-color: #e53935;
    }

    /* Responsiveness */
    @media (max-width: 600px) {
      .form-grid {
        grid-template-columns: 1fr;
      }

      h2 {
        font-size: 1.6rem;
      }

      .modal {
        padding: 20px;
      }
    }

    .modal::-webkit-scrollbar {
      width: 10px;
    }

    .modal::-webkit-scrollbar-thumb {
      background-color: #888;
      border-radius: 10px;
      transition: background-color 0.3s ease;
    }

    .modal::-webkit-scrollbar-thumb:hover {
      background-color: #555;
    }

    .modal::-webkit-scrollbar-track {
      background-color: #f1f1f1;
      border-radius: 10px;
    }
  `],
  imports: [CommonModule, ReactiveFormsModule]
})
export class AddPropertyComponent {
  propertyTypes = ['Apartment', 'House', 'Condo'];
  statuses = ['Available', 'Rented'];
  furnishedLevels = ['None', 'Semi', 'Fully'];
  @Input() propertyToEdit: any = null;
  @Input() searchProperty: any = null;
  @Output() closeModal = new EventEmitter();
  @Output() propertyAdded = new EventEmitter();
  @Output() applyFilters = new EventEmitter();
  propertyForm: FormGroup;
  initialFormValues: any;
  landLordId!: any;
  countries: string[] = [];
  states: string[] = [];
  cities: string[] = [];
  selectedCountry: string = "India";
  selectedState!: string;
  selectedCity!: string;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.propertyForm = this.fb.group({
      title: ['', Validators.required],
      address: ['', Validators.required],
      rentPrice: ['', Validators.required],
      propertyType: ['', Validators.required],
      description: ['', Validators.required],
      status: ['', Validators.required],
      bedrooms: ['', Validators.required],
      furnished: [false],
      parkingIncluded: [false],
      petsAllowed: [false],
      additionalNotes: [''],
      landlordId: this.landLordId,
      country: ['', Validators.required],
      state: ['', Validators.required],
      city: ['', Validators.required], 
    });
  }

  ngOnInit() {
    if (this.propertyToEdit) {
      this.propertyForm.patchValue(this.propertyToEdit);
      const addressValues = this.propertyToEdit.address.split(",");
      const updatedAddress = addressValues.slice(0, -3).join(",").trim();
      const addressValuesLength = addressValues.length || 0;
      this.selectedCountry=addressValues[addressValuesLength - 1].trimStart() || '';
      this.selectedState=addressValues[addressValuesLength - 2].trimStart() || '';
      this.selectedCity=addressValues[addressValuesLength - 3].trimStart() || '';
      this.propertyForm.patchValue({
        address: updatedAddress,
        city: this.selectedCity,
        state: this.selectedState,
        country: this.selectedCountry
      });    
    }
    if(this.searchProperty){
      Object.keys(this.propertyForm.controls).forEach(controlName => {
        const control = this.propertyForm.get(controlName);
        if (control) {
          control.clearValidators();
          control.updateValueAndValidity();
        }
      });
      this.propertyForm.removeControl('address');
      this.propertyForm.removeControl('description');
      this.propertyForm.removeControl('landlordId');
      this.propertyForm.removeControl('additionalNotes');
      this.propertyForm.addControl('minAmount', this.fb.control(''));
      this.propertyForm.addControl('maxAmount', this.fb.control(''));
    }
    this.fetchCountries();
    this.initialFormValues = this.propertyForm.getRawValue();
    const user = localStorage.getItem('user');
    if (user) {
      const userObj = JSON.parse(user);
      this.landLordId = userObj.userId;
    }
  }

  isFormChanged(): boolean {
    return JSON.stringify(this.propertyForm.getRawValue()) !== JSON.stringify(this.initialFormValues);
  }

  fetchCountries() {
    this.http
      .get<any>('https://countriesnow.space/api/v0.1/countries/iso')
      .subscribe((data) => {
        this.countries = data.data.map((countries: any)=> countries.name);
        if(this.propertyToEdit){
          this.propertyForm.patchValue({
            country: this.selectedCountry
          })
          this.fetchStates();
        }
      });
  }

  fetchStates() {
    let payLoad = {
      "country": this.selectedCountry
    }
    this.http
      .post<any>('https://countriesnow.space/api/v0.1/countries/states', payLoad)
      .subscribe((data) => {
        this.states = data.data.states.map((state: any)=> state.name);
        if(this.propertyToEdit){
          this.propertyForm.patchValue({
            state: this.selectedState
          })
          this.fetchCities();
        }
      });
  }

  fetchCities() {
    let payLoad = {
      "country": this.selectedCountry,
      "state": this.selectedState
    }
    this.http
      .post<any>(`https://countriesnow.space/api/v0.1/countries/state/cities`, payLoad)
      .subscribe((data) => {
        this.cities = data.data;
        if(this.propertyToEdit){
          this.propertyForm.patchValue({
            city: this.selectedCity
          })
        }
      });
  }

  onCountryChange(e: any) {
    const selectElement = e.target as HTMLSelectElement;
    this.selectedCountry = selectElement.value;
    this.fetchStates();
  }

  onStateChange(e: any) {
    const selectElement = e.target as HTMLSelectElement;
    this.selectedState = selectElement.value;
    this.fetchCities();
  }

  onCityChange(e: any) {
    const selectElement = e.target as HTMLSelectElement;
    this.selectedCity = selectElement.value;
  }

  onSubmit() {
    if (this.propertyForm.valid && !this.searchProperty) {
      let property = this.propertyForm.value;
      property.landlordId= this.landLordId
      property.address = `${property.address}, ${this.selectedCity}, ${this.selectedState}, ${this.selectedCountry}`
      if (this.propertyToEdit) {
        property.propertyId = this.propertyToEdit.propertyId;
        this.http.put(`http://localhost:5132/api/Properties/${this.propertyToEdit.propertyId}`, property)
          .subscribe({
            next: () => {
              this.propertyAdded.emit();
              this.onClose();
            },
            error: (error) => console.error('Error updating property:', error)
          });
      } else {
        this.http.post('http://localhost:5132/api/Properties', property)
          .subscribe({
            next: () => {
              this.propertyAdded.emit();
              this.onClose();
            },
            error: (error) => console.error('Error adding property:', error)
          });
      }
    } else {
      this.applyFilters.emit(this.propertyForm.getRawValue())
    }
  }

  onClose() {
    this.closeModal.emit();
  }
}

