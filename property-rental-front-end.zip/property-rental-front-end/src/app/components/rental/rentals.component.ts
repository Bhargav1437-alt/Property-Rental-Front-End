import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-notification-table',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule],
  template: `
    <div class="table-container" *ngIf="notifications.length > 0">
      <table class="styled-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Additional Comments</th>
            <th>Received Date & Time</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let notification of notifications">
            <td>{{ notification.name }}</td>
            <td>{{ notification.email }}</td>
            <td>{{ notification.phone }}</td>
            <td>{{ notification.additionalComments || 'No Comments' }}</td>
            <td>{{ notification.receivedDateTime | date: 'yyyy-MM-dd HH:mm:ss':'UTC+5:30' }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <div *ngIf="notifications.length === 0 && !isLoading" class="no-data">
      No notifications available.
    </div>
    <div *ngIf="isLoading" class="loading">
      Loading data...
    </div>
  `,
  styles: [
    `
      .table-container {
        margin: 20px auto;
        width: 90%;
        max-width: 1200px;
        overflow-x: auto;
        border-radius: 8px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        background: #ffffff;
      }
      .styled-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 16px;
        text-align: left;
      }
      .styled-table thead {
        background: #4caf50;
        color: #ffffff;
      }
      .styled-table th {
        padding: 12px 15px;
        text-transform: uppercase;
      }
      .styled-table tbody tr {
        border-bottom: 1px solid #dddddd;
        transition: background 0.3s ease;
      }
      .styled-table tbody tr:nth-of-type(even) {
        background: #f3f3f3;
      }
      .styled-table tbody tr:hover {
        background: #f1f1f1;
        cursor: pointer;
      }
      .styled-table td {
        padding: 12px 15px;
        color: #333333;
        word-wrap: break-word;
        max-width: 200px;
      }
      .no-data,
      .loading {
        text-align: center;
        margin: 20px 0;
        color: #666666;
        font-size: 18px;
        font-weight: 500;
      }
    `,
  ],
})
export class RentalsComponent implements OnInit {
  notifications: any[] = [];
  isLoading = false;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    const user = localStorage.getItem('user');
    if (user) {
      const userObj = JSON.parse(user);
      this.fetchNotifications(userObj.userId);
    }
  }

  fetchNotifications(userId: number) {
    this.isLoading = true;
    this.http.get<any[]>(`http://localhost:5132/api/Notifications/landlord/${userId}`).subscribe(
      (data) => {
        this.notifications = data;
        this.isLoading = false;
      },
      (error) => {
        console.error('Error fetching notifications:', error);
        this.isLoading = false;
      }
    );
  }
}
